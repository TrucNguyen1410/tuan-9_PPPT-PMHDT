﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab7 
{
    public partial class Form3 : Form
    {
       
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QuanLyBanSach;Integrated Security=True;TrustServerCertificate=True;";

        // Doi tuong ket noi 
        SqlConnection sqlCon = null;
        SqlDataAdapter adapter = null;
        DataSet ds = null;

        public Form3()
        {
            InitializeComponent();
        }

        // Ham mo ket noi 
        private void MoKetoi()
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }

        // Ham dong ket noi
        private void DongKetoi()
        {
            
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();
            }
        }

        // Ham xoa du lieu cua cac control 
        private void XoaDuLieuForm()
        {
            txtMaXB.Text = txtTenXB.Text = txtDiaChi.Text = "";
            txtMaXB.ReadOnly = false; 
            vt = -1; 
        }

        // Ham hien thi du lieu tren datagridview 
        private void ienThiDuLieu()
        {
            MoKetoi();
           
            string query = "select * from NhaXuatBan";
            adapter = new SqlDataAdapter(query, sqlCon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            
            adapter.Fill(ds, "tblNhaXuatBan");
            dgvDanhSach.DataSource = ds.Tables["tblNhaXuatBan"];
            DongKetoi();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            ienThiDuLieu();
            XoaDuLieuForm();
        }

        int vt = -1;
        private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vt = e.RowIndex;
            if (vt == -1) return; // Nếu click vào tiêu đề thì bỏ qua

           
            DataRow row = ds.Tables["tblNhaXuatBan"].Rows[vt];

          
            txtMaXB.Text = row["MaXB"].ToString().Trim();
            txtTenXB.Text = row["TenXB"].ToString().Trim();
            txtDiaChi.Text = row["DiaChi"].ToString().Trim();

            txtMaXB.ReadOnly = true; // Không cho phép sửa Mã NXB (vì là khóa chính)
        }

        private void btnChinhSuaThongTin_Click(object sender, EventArgs e)
        {
            if (vt == -1)
            {
                MessageBox.Show("Bạn chưa chọn dữ liệu để chỉnh sửa!");
                return;
            }

            try
            {
               
                DataRow row = ds.Tables["tblNhaXuatBan"].Rows[vt];
                row.BeginEdit();

                
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = txtDiaChi.Text.Trim();
                row.EndEdit();

                int kq = adapter.Update(ds.Tables["tblNhaXuatBan"]);
                if (kq > 0)
                {
                    MessageBox.Show("Chỉnh sửa dữ liệu thành công!");
                    ienThiDuLieu();
                    XoaDuLieuForm();
                }
                else
                {
                    MessageBox.Show("Chỉnh sửa dữ liệu không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                DongKetoi();
            }
        }
    }
}