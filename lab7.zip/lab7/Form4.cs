﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab7 // Hoặc tên namespace của bạn
{
    public partial class Form4 : Form
    {
        // Chuỗi kết nối đúng của bạn
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QuanLyBanSach;Integrated Security=True;TrustServerCertificate=True;";

        // Doi tuong ket noi 
        SqlConnection sqlCon = null;
        SqlDataAdapter adapter = null;
        DataSet ds = null;
        int vt = -1; // Biến lưu vị trí hàng được chọn

        public Form4()
        {
            InitializeComponent();
        }

        // Ham mo ket noi 
        private void MoKetoi()
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }

        // Ham dong ket noi
        private void DongKetoi()
        {
            // Đã sửa 'fifi' thành '&&'
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();
            }
        }

        // Ham hien thi du lieu tren datagridview 
        private void ienThiDuLieu()
        {
            MoKetoi();
            // Đã sửa tên bảng thành NhaXuatBan
            string query = "select * from NhaXuatBan";
            adapter = new SqlDataAdapter(query, sqlCon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();

            // === DÒNG SỬA LỖI ĐÃ THÊM ===
            // Thêm dòng này để SqlCommmandBuilder biết khóa chính là cột nào
            adapter.FillSchema(ds, SchemaType.Source, "tblNhaXuatBan");

            // Đã sửa tên bảng trong DataSet thành tblNhaXuatBan
            adapter.Fill(ds, "tblNhaXuatBan");
            dgvDanhSach.DataSource = ds.Tables["tblNhaXuatBan"];
            DongKetoi();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            ienThiDuLieu();
        }

        private void dgvDanhSach_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vt = e.RowIndex; // Lấy vị trí hàng được click
        }

        private void btnXoaDuLieu_Click(object sender, EventArgs e)
        {
            if (vt == -1)
            {
                MessageBox.Show("Bạn chưa chọn dữ liệu để xóa!");
                return;
            }

            DialogResult result = MessageBox.Show("Bạn có thực sự muốn xóa hay không?", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                XoaDuLieu();
                ienThiDuLieu(); // Tải lại dữ liệu
                vt = -1; // Đặt lại vị trí
            }
        }

        // Ham xoa du lieu 
        private void XoaDuLieu()
        {
            try
            {
                // Đã sửa tên bảng
                DataRow row = ds.Tables["tblNhaXuatBan"].Rows[vt];
                row.Delete(); // Đánh dấu hàng để xóa

                // Cập nhật thay đổi về CSDL
                int kq = adapter.Update(ds.Tables["tblNhaXuatBan"]);
                if (kq > 0)
                {
                    MessageBox.Show("Xóa dữ liệu thành công!");
                }
                else
                {
                    MessageBox.Show("Xóa dữ liệu không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }
    }
}