﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace lab7
{
    public partial class Form1 : Form
    {
        // 🔸 CHUỖI KẾT NỐI ĐÃ SỬA
        // Đã cập nhật Data Source theo ảnh "Connect" của bạn
        // Và thêm 'TrustServerCertificate=True' để tránh lỗi SSL
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QuanLyBanSach;Integrated Security=True;TrustServerCertificate=True;";

        SqlConnection sqlCon = null;

        public Form1()
        {
            InitializeComponent();
        }

        // 🔸 Hàm mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);

            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // 🔸 Hàm đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // 🔸 Nút "Hiển thị"
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();

                string sql = "SELECT * FROM NhaXuatBan";
                SqlDataAdapter adapter = new SqlDataAdapter(sql, sqlCon);

                DataSet ds = new DataSet();
                adapter.Fill(ds, "tblNhaXuatBan");

                dgvDanhSach.DataSource = ds.Tables["tblNhaXuatBan"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}