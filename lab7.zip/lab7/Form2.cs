﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab7 // Hoặc tên namespace của bạn
{
    public partial class Form2 : Form
    {
        // Chuoi ket noi - ĐÃ SỬA DÙNG SERVER ĐÚNG CỦA BẠN
        string strCon = @"Data Source=DESKTOP-AV9ONFH\SQLEXPRESS;Initial Catalog=QuanLyBanSach;Integrated Security=True;TrustServerCertificate=True;";

        // Doi tuong ket noi 
        SqlConnection sqlCon = null;
        SqlDataAdapter adapter = null;
        DataSet ds = null;

        public Form2()
        {
            InitializeComponent();
        }

        // Ham mo ket noi 
        private void MoKetoi()
        {
            if (sqlCon == null)
            {
                sqlCon = new SqlConnection(strCon);
            }
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }

        // Ham dong ket noi 
        private void DongKetoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();
            }
        }

        // Ham xoa du lieu cua cac control 
        private void XoaDuLieuForm()
        {
            txtMaXB.Text = txtTenXB.Text = txtDiaChi.Text = "";
            txtMaXB.Focus();
        }

        // Ham hien thi du lieu tren datagridview 
        private void ienThiDuLieu()
        {
            MoKetoi();

            // === SỬA LỖI 1 ===
            // Tên bảng đúng là 'NhaXuatBan' (như bài 1), không phải 'haXuatBan'
            string query = "select * from NhaXuatBan";

            adapter = new SqlDataAdapter(query, sqlCon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();

            // === SỬA LỖI 2 ===
            // Tên bảng trong DataSet phải là 'tblNhaXuatBan'
            adapter.Fill(ds, "tblNhaXuatBan");
            dgvDanhSach.DataSource = ds.Tables["tblNhaXuatBan"];

            DongKetoi();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            ienThiDuLieu();
            XoaDuLieuForm();
        }

        private void btnThemDL_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetoi();

                DataRow row = ds.Tables["tblNhaXuatBan"].NewRow();

                // === SỬA LỖI 3 ===
                // Tên cột đúng là 'MaXB' (như trong DataGridView), không phải 'XB'
                row["MaXB"] = txtMaXB.Text.Trim();
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = txtDiaChi.Text.Trim();

                ds.Tables["tblNhaXuatBan"].Rows.Add(row);

                // Cập nhật lên CSDL
                int kq = adapter.Update(ds.Tables["tblNhaXuatBan"]);
                if (kq > 0)
                {
                    MessageBox.Show("Thêm dữ liệu thành công!");
                    ienThiDuLieu(); // Tải lại dữ liệu
                    XoaDuLieuForm(); // Xóa các ô text
                }
                else
                {
                    MessageBox.Show("Thêm dữ liệu không thành công!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
            finally
            {
                DongKetoi();
            }
        }
    }
}